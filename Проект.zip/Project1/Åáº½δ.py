import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QWidget, QApplication, QPushButton, QLabel, QTableWidget, QLineEdit
from PyQt5.QtWidgets import QTableWidgetItem, QMainWindow, QFileDialog
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtCore import Qt
from PIL import Image
from random import shuffle
import sqlite3
import time


class Reference(QWidget):
    def __init__(self, background):
        super().__init__()
        self.background = background
        uic.loadUi('project_5.ui', self)
        self.initUI()

    def initUI(self):
        self.setStyleSheet("background-color:" + self.background)
        self.pushButton.clicked.connect(self.close)
        self.fname = 'good luck.png'
        self.pixmap = QPixmap(self.fname)
        self.label_2.setPixmap(self.pixmap)


class Settings(QWidget):
    '''Класс окна настройки фона'''
    def __init__(self, background, menu):
        super().__init__()
        self.background = background
        self.menu = menu
        uic.loadUi('project_6.ui', self)
        self.initUI()

    def initUI(self):
        self.setStyleSheet("background-color:" + self.background)
        self.buttonGroup.buttonClicked.connect(self.set_background_color)
        self.pushButton.clicked.connect(self.get_colors)

    def get_colors(self):
        '''Функция получения цвета фона'''
        self.mm = MainMenu(self.background, self.menu)
        self.mm.show()
        self.close()

    def set_background_color(self, sender):
        '''Изменение цвета фона окна настройки фона'''
        if sender.text() == 'Белый':
            color = 'white'
            self.menu = 'blue'
        elif sender.text() == 'Серый':
            color = 'gray'
            self.menu = color
        else:
            color = 'rgb(207, 155, 143)'
            self.menu = color
        self.background = color
        self.setStyleSheet("background-color:" + self.background)
        self.radioButton.setStyleSheet("background-color:" + self.background)
        self.radioButton_2.setStyleSheet("background-color:" + self.background)
        self.radioButton_3.setStyleSheet("background-color:" + self.background)


class MainMenu(QMainWindow):
    '''Класс стартового меню'''
    def __init__(self, background='white', menu='blue'):
        super().__init__()
        self.background = background
        self.menu_color = menu
        uic.loadUi('project_0.ui', self)
        self.initUI()

    def initUI(self):
        self.setStyleSheet("background-color:" + self.background)
        self.menu.setStyleSheet("""QMenu::item::selected {
            background-color: """ + self.menu_color + "})")
        self.pushButton.clicked.connect(self.open_greeting)
        self.pushButton_2.clicked.connect(sys.exit)
        self.action.triggered.connect(self.show_reference)
        self.action_2.triggered.connect(self.set_settings)
        self.fname = 'puzzles.png'
        self.pixmap = QPixmap(self.fname)
        self.label.setPixmap(self.pixmap)

    def open_greeting(self):
        self.greet = Greeting(self.background)
        self.close()
        self.greet.show()

    def set_settings(self):
        self.settings = Settings(self.background, self.menu_color)
        self.settings.show()
        self.close()

    def show_reference(self):
        self.ref = Reference(self.background)
        self.ref.show()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_F1:
            self.show_reference()


class Greeting(QWidget):
    '''Класс выбора имени пользователем'''
    def __init__(self, background):
        super().__init__()
        uic.loadUi('project_1.ui', self)
        self.background = background
        self.initUI()

    def initUI(self):
        self.setStyleSheet("background-color:" + self.background)
        self.pushButton.clicked.connect(self.greet)

    def greet(self):
        text = self.lineEdit.text()
        if text:
            self.current_player = text
            self.openChoosePicture()

    def openChoosePicture(self):
        self.ChoosePicture = ChoosePicture(self.current_player, self.background)
        self.close()
        self.ChoosePicture.show()


class ChoosePicture(QWidget):
    '''Класс выбора картинки пользователем'''
    def __init__(self, current_player, background):
        super().__init__()
        self.current_player = current_player
        self.background = background
        uic.loadUi('project_2.ui', self)
        self.initUI()

    def initUI(self):
        self.setStyleSheet("background-color:" + self.background)
        self.pushButton.clicked.connect(self.loadPicture)

    def loadPicture(self):
        self.fname = ''
        self.fname = QFileDialog.getOpenFileName(self, 'Выбрать картинку', '', 'Картинка(*.png)')[0]
        if self.fname:
            self.im = Image.open(self.fname)
            x, y = self.im.size
            if x > 500:
                x = 500
            if y > 500:
                y = 500
            self.label.resize(x, y)
            self.im.crop((0, 0, x, y))
            self.pixmap = QPixmap(self.fname)
            self.label.setPixmap(self.pixmap)
            self.pushButton_2.clicked.connect(self.openGame)

    def openGame(self):
        self.Game = Game(self.current_player, self.im, self.background)
        self.close()
        self.Game.show()


class Game(QWidget):
    '''Класс игры'''
    def __init__(self, current_player, image, background):
        super().__init__()
        uic.loadUi('project_3.ui', self)
        self.current_player = current_player
        self.image = image
        self.background = background
        image.save('temp.png')
        self.flag_pair = False
        self.last_btn = None
        self.pre_last_btn = None
        self.time_start = time.time()
        self.initUI()

    def initUI(self):
        self.setStyleSheet("background-color:" + self.background)
        # Объявление кнопок
        self.pushButton.clicked.connect(self.change)
        self.pushButton_2.clicked.connect(self.change)
        self.pushButton_3.clicked.connect(self.change)
        self.pushButton_4.clicked.connect(self.change)
        self.pushButton_5.clicked.connect(self.change)
        self.pushButton_6.clicked.connect(self.change)
        self.pushButton_7.clicked.connect(self.change)
        self.pushButton_8.clicked.connect(self.change)
        self.pushButton_9.clicked.connect(self.change)
        self.pushButton_10.clicked.connect(self.change)
        self.pushButton_11.clicked.connect(self.change)
        self.pushButton_12.clicked.connect(self.change)
        self.pushButton_13.clicked.connect(self.change)
        self.pushButton_14.clicked.connect(self.change)
        self.pushButton_15.clicked.connect(self.change)
        self.pushButton_16.clicked.connect(self.change)
        self.pushButton_17.clicked.connect(self.change)
        self.pushButton_18.clicked.connect(self.change)
        self.pushButton_19.clicked.connect(self.change)
        self.pushButton_20.clicked.connect(self.change)
        self.pushButton_21.clicked.connect(self.change)
        self.pushButton_22.clicked.connect(self.change)
        self.pushButton_23.clicked.connect(self.change)
        self.pushButton_24.clicked.connect(self.change)
        self.pushButton_25.clicked.connect(self.change)
        self.pushButton_26.clicked.connect(self.cancelTurn)
        self.pushButton_27.clicked.connect(self.cancelChoice)

        x_const, y_const = self.image.size
        self.label.resize(x_const, y_const)
        self.pixmap = QPixmap('temp.png')
        self.label.setPixmap(self.pixmap)
        x = x_const // 5
        y = y_const // 5
        # Настройка размеров кнопок
        self.pushButton.resize(x, y)
        self.pushButton_2.resize(x, y)
        self.pushButton_3.resize(x, y)
        self.pushButton_4.resize(x, y)
        self.pushButton_5.resize(x, y)
        self.pushButton_6.resize(x, y)
        self.pushButton_7.resize(x, y)
        self.pushButton_8.resize(x, y)
        self.pushButton_9.resize(x, y)
        self.pushButton_10.resize(x, y)
        self.pushButton_11.resize(x, y)
        self.pushButton_12.resize(x, y)
        self.pushButton_13.resize(x, y)
        self.pushButton_14.resize(x, y)
        self.pushButton_15.resize(x, y)
        self.pushButton_16.resize(x, y)
        self.pushButton_17.resize(x, y)
        self.pushButton_18.resize(x, y)
        self.pushButton_19.resize(x, y)
        self.pushButton_20.resize(x, y)
        self.pushButton_21.resize(x, y)
        self.pushButton_22.resize(x, y)
        self.pushButton_23.resize(x, y)
        self.pushButton_24.resize(x, y)
        self.pushButton_25.resize(x, y)
        # Передвижение кнопок
        self.pushButton_2.move(x + 15, 10)
        self.pushButton_3.move(2 * (x + 5) + 10, 10)
        self.pushButton_4.move(3 * (x + 5) + 10, 10)
        self.pushButton_5.move(4 * (x + 5) + 10, 10)
        self.pushButton_6.move(10, y + 15)
        self.pushButton_7.move(x + 15, y + 15)
        self.pushButton_8.move(2 * (x + 5) + 10, y + 15)
        self.pushButton_9.move(3 * (x + 5) + 10, y + 15)
        self.pushButton_10.move(4 * (x + 5) + 10, y + 15)
        self.pushButton_11.move(10, 2 * (y + 5) + 10)
        self.pushButton_12.move(x + 15, 2 * (y + 5) + 10)
        self.pushButton_13.move(2 * (x + 5) + 10, 2 * (y + 5) + 10)
        self.pushButton_14.move(3 * (x + 5) + 10, 2 * (y + 5) + 10)
        self.pushButton_15.move(4 * (x + 5) + 10, 2 * (y + 5) + 10)
        self.pushButton_16.move(10, 3 * (y + 5) + 10)
        self.pushButton_17.move(x + 15, 3 * (y + 5) + 10)
        self.pushButton_18.move(2 * (x + 5) + 10, 3 * (y + 5) + 10)
        self.pushButton_19.move(3 * (x + 5) + 10, 3 * (y + 5) + 10)
        self.pushButton_20.move(4 * (x + 5) + 10, 3 * (y + 5) + 10)
        self.pushButton_21.move(10, 4 * (y + 5) + 10)
        self.pushButton_22.move(x + 15, 4 * (y + 5) + 10)
        self.pushButton_23.move(2 * (x + 5) + 10, 4 * (y + 5) + 10)
        self.pushButton_24.move(3 * (x + 5) + 10, 4 * (y + 5) + 10)
        self.pushButton_25.move(4 * (x + 5) + 10, 4 * (y + 5) + 10)

        x2, x3, x4, y2, y3, y4 = x * 2, x * 3, x * 4, y * 2, y * 3, y * 4

        # Разрезаем изображение на 25 частей
        im1 = self.image.crop((0, 0, x, y))
        im2 = self.image.crop((x, 0, x2, y))
        im3 = self.image.crop((x2, 0, x3, y))
        im4 = self.image.crop((x3, 0, x4, y))
        im5 = self.image.crop((x4, 0, x_const, y))
        im6 = self.image.crop((0, y, x, y2))
        im7 = self.image.crop((x, y, x2, y2))
        im8 = self.image.crop((x2, y, x3, y2))
        im9 = self.image.crop((x3, y, x4, y2))
        im10 = self.image.crop((x4, y, x_const, y2))
        im11 = self.image.crop((0, y2, x, y3))
        im12 = self.image.crop((x, y2, x2, y3))
        im13 = self.image.crop((x2, y2, x3, y3))
        im14 = self.image.crop((x3, y2, x4, y3))
        im15 = self.image.crop((x4, y2, x_const, y3))
        im16 = self.image.crop((0, y3, x, y4))
        im17 = self.image.crop((x, y3, x2, y4))
        im18 = self.image.crop((x2, y3, x3, y4))
        im19 = self.image.crop((x3, y3, x4, y4))
        im20 = self.image.crop((x4, y3, x_const, y4))
        im21 = self.image.crop((0, y4, x, y_const))
        im22 = self.image.crop((x, y4, x2, y_const))
        im23 = self.image.crop((x2, y4, x3, y_const))
        im24 = self.image.crop((x3, y4, x4, y_const))
        im25 = self.image.crop((x4, y4, x_const, y_const))

        # Создаём хранилища изображений и порядка их номеров
        self.pict_dict = {1: im1, 2: im2, 3: im3, 4: im4, 5: im5, 6: im6, 7: im7, 8: im8, 9: im9, 10: im10,
                          11: im11, 12: im12, 13: im13, 14: im14, 15: im15, 16: im16, 17: im17,
                          18: im18, 19: im19, 20: im20, 21: im21, 22: im22, 23: im23, 24: im24, 25: im25}
        self.pict_data_start = [i for i in range(1, 26)]
        self.pict_data_cur = self.pict_data_start[:]
        shuffle(self.pict_data_cur)
        self.names_dict = {}

        # Сохраняем изображения
        for i in range(1, 26):
            fname = 'im_' + str(i) + '.png'
            im = self.pict_dict[i]
            im.save(fname)
            self.names_dict[i] = fname

        # Выводим изображения на кнопки
        self.im_to_btn(self.pushButton, self.names_dict[self.pict_data_cur[0]])
        self.im_to_btn(self.pushButton_2, self.names_dict[self.pict_data_cur[1]])
        self.im_to_btn(self.pushButton_3, self.names_dict[self.pict_data_cur[2]])
        self.im_to_btn(self.pushButton_4, self.names_dict[self.pict_data_cur[3]])
        self.im_to_btn(self.pushButton_5, self.names_dict[self.pict_data_cur[4]])
        self.im_to_btn(self.pushButton_6, self.names_dict[self.pict_data_cur[5]])
        self.im_to_btn(self.pushButton_7, self.names_dict[self.pict_data_cur[6]])
        self.im_to_btn(self.pushButton_8, self.names_dict[self.pict_data_cur[7]])
        self.im_to_btn(self.pushButton_9, self.names_dict[self.pict_data_cur[8]])
        self.im_to_btn(self.pushButton_10, self.names_dict[self.pict_data_cur[9]])
        self.im_to_btn(self.pushButton_11, self.names_dict[self.pict_data_cur[10]])
        self.im_to_btn(self.pushButton_12, self.names_dict[self.pict_data_cur[11]])
        self.im_to_btn(self.pushButton_13, self.names_dict[self.pict_data_cur[12]])
        self.im_to_btn(self.pushButton_14, self.names_dict[self.pict_data_cur[13]])
        self.im_to_btn(self.pushButton_15, self.names_dict[self.pict_data_cur[14]])
        self.im_to_btn(self.pushButton_16, self.names_dict[self.pict_data_cur[15]])
        self.im_to_btn(self.pushButton_17, self.names_dict[self.pict_data_cur[16]])
        self.im_to_btn(self.pushButton_18, self.names_dict[self.pict_data_cur[17]])
        self.im_to_btn(self.pushButton_19, self.names_dict[self.pict_data_cur[18]])
        self.im_to_btn(self.pushButton_20, self.names_dict[self.pict_data_cur[19]])
        self.im_to_btn(self.pushButton_21, self.names_dict[self.pict_data_cur[20]])
        self.im_to_btn(self.pushButton_22, self.names_dict[self.pict_data_cur[21]])
        self.im_to_btn(self.pushButton_23, self.names_dict[self.pict_data_cur[22]])
        self.im_to_btn(self.pushButton_24, self.names_dict[self.pict_data_cur[23]])
        self.im_to_btn(self.pushButton_25, self.names_dict[self.pict_data_cur[24]])

    def get_number(self):
        '''Функция, возвращающая номер нажатой кнопки'''
        if self.sender() == self.pushButton:
            return 1
        if self.sender() == self.pushButton_2:
            return 2
        if self.sender() == self.pushButton_3:
            return 3
        if self.sender() == self.pushButton_4:
            return 4
        if self.sender() == self.pushButton_5:
            return 5
        if self.sender() == self.pushButton_6:
            return 6
        if self.sender() == self.pushButton_7:
            return 7
        if self.sender() == self.pushButton_8:
            return 8
        if self.sender() == self.pushButton_9:
            return 9
        if self.sender() == self.pushButton_10:
            return 10
        if self.sender() == self.pushButton_11:
            return 11
        if self.sender() == self.pushButton_12:
            return 12
        if self.sender() == self.pushButton_13:
            return 13
        if self.sender() == self.pushButton_14:
            return 14
        if self.sender() == self.pushButton_15:
            return 15
        if self.sender() == self.pushButton_16:
            return 16
        if self.sender() == self.pushButton_17:
            return 17
        if self.sender() == self.pushButton_18:
            return 18
        if self.sender() == self.pushButton_19:
            return 19
        if self.sender() == self.pushButton_20:
            return 20
        if self.sender() == self.pushButton_21:
            return 21
        if self.sender() == self.pushButton_22:
            return 22
        if self.sender() == self.pushButton_23:
            return 23
        if self.sender() == self.pushButton_24:
            return 24
        return 25


    def change(self):
        '''Функция, рагирующая на нажатие кнопки'''
        n = self.get_number() - 1
        if self.flag_pair:
            # Действия, если нажато 2 кнопки
            self.label_2.setText('')
            self.pict_data_cur[self.last], self.pict_data_cur[n] = self.pict_data_cur[n], self.pict_data_cur[self.last]
            im1 = self.pict_dict[self.pict_data_cur[self.last]]
            im2 = self.pict_dict[self.pict_data_cur[n]]
            fname1 = 'im_' + str(n + 1) + '.png'
            fname2 = 'im_' + str(self.last + 1) + '.png'
            im1.save(fname1)
            im2.save(fname2)
            self.im_to_btn(self.sender(), fname2)
            self.im_to_btn(self.last_btn, fname1)
            self.pre_last_btn = self.last_btn
            self.last_btn = self.sender()
            self.pre_last = self.last
            self.last = n
            if self.pict_data_cur == self.pict_data_start:
                # Действия, если все картинки стоят на своих местах
                self.time_stop = time.time()
                self.openParting()
        else:
            # Действия, если нажата 1 кнопка
            self.pre_last_btn = None
            self.last = n
            self.last_btn = self.sender()
            self.label_2.setText('Кнопка выбрана, выберите вторую')
        self.flag_pair = not self.flag_pair

    def cancelTurn(self):
        '''Функция, выполняющая отмену одного предыдущего хода'''
        if self.pre_last_btn is not None:
            self.pict_data_cur[self.pre_last], self.pict_data_cur[self.last] = (self.pict_data_cur[self.last],
                                                                                self.pict_data_cur[self.pre_last])
            im1 = self.pict_dict[self.pict_data_cur[self.pre_last]]
            im2 = self.pict_dict[self.pict_data_cur[self.last]]
            fname1 = 'im_' + str(self.last + 1) + '.png'
            fname2 = 'im_' + str(self.pre_last + 1) + '.png'
            im1.save(fname1)
            im2.save(fname2)
            self.im_to_btn(self.last_btn, fname2)
            self.im_to_btn(self.pre_last_btn, fname1)
            self.pre_last_btn = None

    def cancelChoice(self):
        '''Функция, отменяющая выбор кнопки'''
        self.flag_pair = False
        self.label_2.setText('')

    def im_to_btn(self, btn, fname):
        '''Функция, выводящая изображение на кнопку'''
        self.icon = QIcon(fname)
        btn.setIcon(self.icon)

    def openParting(self):
        self.Parting = Parting(self.current_player, self.time_stop - self.time_start, self.background)
        self.close()
        self.Parting.show()


class Parting(QWidget):
    def __init__(self, current_player, time, background):
        super().__init__()
        self.current_player = current_player
        self.background = background
        self.time = time
        uic.loadUi('project_4.ui', self)
        self.initUI()

    def initUI(self):
        self.setStyleSheet("background-color:" + self.background)
        self.pushButton.clicked.connect(self.write_to_file)
        self.pushButton_2.clicked.connect(self.go_to_main_menu)
        self.pushButton_3.clicked.connect(sys.exit)
        self.pushButton_4.clicked.connect(self.restart)
        self.lineEdit.setText(str(int(self.time)))
        self.include_player()
        sred = self.middle_rezult()
        self.lineEdit_2.setText(str(sred))
        con = sqlite3.connect('Пазлы.db')
        res = self.get_record()
        length = 5 if len(res) >= 5 else len(res)
        for i in range(length):
            # Заполняем таблицу рекордами
            id = str(res[i][0])
            cur = con.cursor()
            TextSQL = "SELECT Name FROM Players WHERE id == " + id
            name = QTableWidgetItem(cur.execute(TextSQL).fetchall()[0][0])
            name.setFlags(Qt.ItemIsEnabled)
            self.tableWidget.setItem(i, 0, name)
            time = QTableWidgetItem(str(int(res[i][1])))
            time.setFlags(Qt.ItemIsEnabled)
            self.tableWidget.setItem(i, 1, time)

    def include_player(self):
        '''Функция добавления игрока в БД'''
        con = sqlite3.connect('Пазлы.db')
        cur = con.cursor()
        TextSQL = "SELECT id FROM Players WHERE Name == " + '"' + self.current_player + '"'
        id = cur.execute(TextSQL).fetchall()
        if not id:
            TextSQL = 'INSERT INTO Players(Name) Values("' + self.current_player + '")'
            cur.execute(TextSQL)
        TextSQL = "SELECT id FROM Players WHERE Name == " + '"' + self.current_player + '"'
        id = cur.execute(TextSQL).fetchall()[0][0]
        TextSQL = 'INSERT INTO Records(User, Time) VALUES(' + str(id) + ', ' + str(self.time) + ')'
        cur.execute(TextSQL)
        con.commit()
        con.close()

    def get_record(self):
        '''Функция получения 5-ти лучших результатов'''
        con = sqlite3.connect('Пазлы.db')
        cur = con.cursor()
        TextSQL = """SELECT User, Time FROM Records"""
        result = cur.execute(TextSQL).fetchall()
        result = sorted(result, key=lambda x: (x[1], x[0]))
        con.close()
        return result[:5]

    def write_to_file(self):
        '''Функция записи в файл результатов пользователя'''
        f = open('records.txt', 'w')
        con = sqlite3.connect('Пазлы.db')
        cur = con.cursor()
        TextSQL = ("SELECT Time FROM Records WHERE User IN (SELECT id FROM Players WHERE Name ==  '" +
                   self.current_player + "')")
        result = cur.execute(TextSQL).fetchall()
        result.sort()
        for time in result:
            f.write(str(time[0]) + '\t' + self.current_player + '\n')
        f.close()
        self.label_3.setText('Ваши рекорды записаны в файл "records.txt", находящийся в папке с игрой')

    def go_to_main_menu(self):
        self.m_m = MainMenu(self.background)
        self.close()
        self.m_m.show()

    def restart(self):
        '''Фунция перехода к выбору картинки'''
        self.ch_p = ChoosePicture(self.current_player, self.background)
        self.close()
        self.ch_p.show()

    def middle_rezult(self):
        '''Функция получения среднего арифметического времени игрока'''
        con = sqlite3.connect('Пазлы.db')
        cur = con.cursor()
        TextSQL = ("SELECT Time FROM Records WHERE User IN (SELECT id FROM Players WHERE Name == '" +
                   self.current_player + "')")
        rezult = cur.execute(TextSQL).fetchall()
        s = 0
        for i in rezult:
            s += i[0]
        return int(s / len(rezult))


app = QApplication(sys.argv)
Mm = MainMenu()
Mm.show()
sys.exit(app.exec())
